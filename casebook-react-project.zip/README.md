# Tata Starbucks India: Executive Casebook

Interactive React (Vite) app: payment rails, international corridors, ISO map, reconciliation, unit-economics sliders.
Independent educational research by ICS; not affiliated with Tata Starbucks, Starbucks Corp. or Tata Consumer. Figures marked Assumption are illustrative.

    npm install && npm run dev      # local, hot reload
    npm run build                   # single-file build in dist/

Pushing to `main` deploys to GitHub Pages (Settings → Pages → Source: GitHub Actions).
